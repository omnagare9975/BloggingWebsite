module.exports = {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    colors: {
      // Custom colors
      dark: {
        800: '#1e1b4b',
        900: '#0f172a',
      },
      primary: {
        400: '#a78bfa',
        500: '#8b5cf6',
        600: '#7c3aed',
      },
      // Default colors (include these to prevent conflicts)
      transparent: 'transparent',
      current: 'currentColor',
      white: '#ffffff',
      black: '#000000',
      gray: {
        100: '#f3f4f6',
        // ... other gray shades as needed
      }
    },
    extend: {}, // Keep empty if defining all colors above
  },
  plugins: [],
}